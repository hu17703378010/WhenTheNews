//
//  ReaddetailController.h
//  WhenTheNews
//
//  Created by lanou3g on 16/4/21.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReaddetailController : UIViewController

@property (nonatomic,copy) NSString *URLStr;

@property (nonatomic,copy) NSString *titleString;

@end
