//
//  TopicDetailModel.h
//  WhenTheNews
//
//  Created by lanou3g on 16/4/16.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TopicDetailModel : NSObject

@property (nonatomic,strong) NSString *alias;
@property (nonatomic,strong) NSString *expertId;
@property (nonatomic,strong) NSString *picurl;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *Description;
@property (nonatomic,strong) NSString *headpicurl;
@property (nonatomic,strong) NSString *state;
@property (nonatomic,strong) NSString *stitle;
@property (nonatomic,strong) NSString *concernCount;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *questionCount;
@property (nonatomic,strong) NSString *answerCount;

@end
