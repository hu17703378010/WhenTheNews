//
//  ConstantsDefine.h
//  WhenTheNews
//
//  Created by lanou3g on 16/4/16.
//  Copyright © 2016年 HCC. All rights reserved.
//

#ifndef ConstantsDefine_h
#define ConstantsDefine_h

#pragma mark -屏幕尺寸-
//屏幕宽
#define ScreenWidth     [[UIScreen mainScreen] bounds].size.width
//屏幕高
#define ScreenHeight    [[UIScreen mainScreen] bounds].size.height
//导航条高度
#define NavigationBarHeight     64.0

#pragma mark -颜色-




#endif /* ConstantsDefine_h */
