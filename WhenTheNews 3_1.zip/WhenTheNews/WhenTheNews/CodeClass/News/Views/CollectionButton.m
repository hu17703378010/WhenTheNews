//
//  CollectionButton.m
//  WhenTheNews
//
//  Created by lanou3g on 16/4/22.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import "CollectionButton.h"

@implementation CollectionButton

@end
