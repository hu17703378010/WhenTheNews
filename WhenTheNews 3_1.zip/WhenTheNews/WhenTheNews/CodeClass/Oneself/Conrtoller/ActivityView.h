//
//  ActivityView.h
//  News
//
//  Created by lanou3g on 15/7/9.
//  Copyright (c) 2015年 lanou3g. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityView : UIView

@property (nonatomic , retain) UIImageView *imageView;

- (void)layoutView;
- (void)endClearView;

@end
