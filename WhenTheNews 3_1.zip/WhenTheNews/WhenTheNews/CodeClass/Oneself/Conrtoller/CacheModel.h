//
//  CacheModel.h
//  WhenTheNews
//
//  Created by lanou3g on 16/4/20.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CacheModel : NSObject

@property (nonatomic,copy) NSString *cache;

@end
