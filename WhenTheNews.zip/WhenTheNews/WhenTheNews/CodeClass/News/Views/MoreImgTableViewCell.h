//
//  MoreImgTableViewCell.h
//  WhenTheNews
//
//  Created by lanou3g on 16/4/18.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreImgTableViewCell : UITableViewCell

@end
