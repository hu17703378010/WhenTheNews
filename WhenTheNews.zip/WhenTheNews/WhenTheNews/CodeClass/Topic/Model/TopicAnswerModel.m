//
//  TopicAnswerModel.m
//  WhenTheNews
//
//  Created by lanou3g on 16/4/18.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import "TopicAnswerModel.h"

@implementation TopicAnswerModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
