//
//  ReaddetailController.m
//  WhenTheNews
//
//  Created by lanou3g on 16/4/21.
//  Copyright © 2016年 HCC. All rights reserved.
//http://c.m.163.com/nc/article/%@/full.html

#import "ReaddetailController.h"
#import "AFNetworking.h"
#import "NSString+Html.h"

#define header @"http://c.m.163.com/nc/article/"

#define footer @"full.html"

@interface ReaddetailController ()

@property (nonatomic,strong)UIWebView *webView;

@property (nonatomic,copy)NSString *contentString;

@end

@implementation ReaddetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.webView = [[UIWebView alloc]initWithFrame:self.view.bounds];
    
    
}

- (void)request{
    NSString *string = [NSString stringWithFormat:@"%@%@%@",header,self.Id,footer];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"application/x-json",@"text/html", nil];
    [manager GET:string parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:responseObject];
        _contentString = [dic objectForKey:self.Id];
        _webView.scalesPageToFit = NO;
        //把原来的html通过importStyleWithHtmlString进行替换，修改html的布局
        NSString *newString = [NSString importStyleWithHtmlString:_contentString];
        //baseURL可以让界面加载的时候按照本地样式去加载
        NSURL *baseURL = [NSURL fileURLWithPath:[NSBundle mainBundle].bundlePath];
        [_webView loadHTMLString:newString baseURL:baseURL];

        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
