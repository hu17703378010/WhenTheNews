//
//  TopicQuestionModel.m
//  WhenTheNews
//
//  Created by lanou3g on 16/4/18.
//  Copyright © 2016年 HCC. All rights reserved.
//

#import "TopicQuestionModel.h"

@implementation TopicQuestionModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
